package com.asm.fortuneteller.model;

import java.io.Serializable;

public class Fortune implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private int idASM;
    private String contentASM;
    private String typeASM; // "positive" or "negative"
    
    public Fortune() {
    }
    
    public Fortune(String contentASM, String typeASM) {
        this.contentASM = contentASM;
        this.typeASM = typeASM;
    }
    
    public Fortune(int idASM, String contentASM, String typeASM) {
        this.idASM = idASM;
        this.contentASM = contentASM;
        this.typeASM = typeASM;
    }
    
    public int getIdASM() {
        return idASM;
    }
    
    public void setIdASM(int idASM) {
        this.idASM = idASM;
    }
    
    public String getContentASM() {
        return contentASM;
    }
    
    public void setContentASM(String contentASM) {
        this.contentASM = contentASM;
    }
    
    public String getTypeASM() {
        return typeASM;
    }
    
    public void setTypeASM(String typeASM) {
        this.typeASM = typeASM;
    }
}