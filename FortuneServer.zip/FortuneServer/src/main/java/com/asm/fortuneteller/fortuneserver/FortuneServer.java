package com.asm.fortuneteller.fortuneserver;

import com.asm.fortuneteller.dao.FortuneDAO;
import com.asm.fortuneteller.dao.UserDAO;
import com.asm.fortuneteller.gui.ServerGUI;
import com.asm.fortuneteller.model.Fortune;
import com.asm.fortuneteller.model.Message;
import com.asm.fortuneteller.model.User;
import com.asm.fortuneteller.util.SentimentAnalyzer;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FortuneServer {
   private static final int PORT_ASM = 5555;
   private ServerSocket serverSocketASM;
   private ExecutorService threadPoolASM;
   private boolean runningASM;
   private ServerGUI guiASM;
   private UserDAO userDAOASM;
   private FortuneDAO fortuneDAOASM;
   private SentimentAnalyzer sentimentAnalyzerASM;
   
   public FortuneServer(ServerGUI guiASM) {
       this.guiASM = guiASM;
       this.threadPoolASM = Executors.newCachedThreadPool();
       this.userDAOASM = new UserDAO();
       this.fortuneDAOASM = new FortuneDAO();
       this.sentimentAnalyzerASM = new SentimentAnalyzer();
       
       this.userDAOASM.initializeTable();
       this.fortuneDAOASM.initializeTable();
   }
   
   public void startServer() {
       runningASM = true;
       
       try {
           serverSocketASM = new ServerSocket(PORT_ASM);
           System.out.println("Server started and listening on port " + PORT_ASM);
           
           if (guiASM != null) {
               guiASM.updateServerStatus("Server running on port " + PORT_ASM);
           }
           
           while (runningASM) {
               try {
                   System.out.println("Waiting for client connections...");
                   Socket clientSocketASM = serverSocketASM.accept();
                   System.out.println("New client connected: " + clientSocketASM.getInetAddress().getHostAddress());
                   
                   ClientHandler clientHandlerASM = new ClientHandler(clientSocketASM);
                   threadPoolASM.submit(clientHandlerASM);
               } catch (IOException e) {
                   if (!runningASM) {
                       break;
                   }
                   System.err.println("Error accepting client connection: " + e.getMessage());
               }
           }
       } catch (IOException e) {
           System.err.println("Error starting server: " + e.getMessage());
           e.printStackTrace();
           
           if (guiASM != null) {
               guiASM.updateServerStatus("Server failed to start: " + e.getMessage());
           }
       } finally {
           stopServer();
       }
   }
   
   public void stopServer() {
       runningASM = false;
       
       try {
           if (serverSocketASM != null && !serverSocketASM.isClosed()) {
               serverSocketASM.close();
               System.out.println("Server stopped");
               
               if (guiASM != null) {
                   guiASM.updateServerStatus("Server stopped");
               }
           }
       } catch (IOException e) {
           System.err.println("Error closing server socket: " + e.getMessage());
       }
       
       threadPoolASM.shutdown();
   }
   
   private class ClientHandler implements Runnable {
       private Socket clientSocketASM;
       private ObjectInputStream inputASM;
       private ObjectOutputStream outputASM;
       private User currentUserASM;
       private boolean clientConnectedASM = false;
       
       public ClientHandler(Socket clientSocketASM) {
           this.clientSocketASM = clientSocketASM;
           try {
               System.out.println("Setting up streams for client: " + clientSocketASM.getInetAddress().getHostAddress());
               outputASM = new ObjectOutputStream(clientSocketASM.getOutputStream());
               inputASM = new ObjectInputStream(clientSocketASM.getInputStream());
               clientConnectedASM = true;
               System.out.println("Client handler initialized successfully");
               
               if (guiASM != null) {
                   guiASM.updateConnectionStatus(true);
               }
           } catch (IOException e) {
               System.err.println("Error setting up client streams: " + e.getMessage());
               e.printStackTrace();
               closeConnection();
           }
       }
       
       @Override
       public void run() {
           try {
               while (clientConnectedASM) {
                   System.out.println("Waiting for client message...");
                   Message messageASM = (Message) inputASM.readObject();
                   System.out.println("Received message of type: " + messageASM.getTypeASM());
                   processMessage(messageASM);
               }
           } catch (IOException | ClassNotFoundException e) {
               System.err.println("Error in client communication: " + e.getMessage());
               e.printStackTrace();
           } finally {
               closeConnection();
           }
       }
       
       private void processMessage(Message messageASM) throws IOException {
           switch (messageASM.getTypeASM()) {
               case Message.LOGIN_REQUEST:
                   handleLoginRequest(messageASM);
                   break;
               case Message.SIGNUP_REQUEST:
                   handleSignupRequest(messageASM);
                   break;
               case Message.FORTUNE_REQUEST:  
                   handleFortuneRequest(messageASM);
                   break;
               case Message.CHAT_MESSAGE:
                   handleChatMessage(messageASM);
                   break;
               case Message.DISCONNECT:
                   System.out.println("Client requested disconnect");
                   closeConnection();
                   break;
               default:
                   System.out.println("Unknown message type: " + messageASM.getTypeASM());
                   break;
           }
       }
       
       private void handleFortuneRequest(Message messageASM) throws IOException {
           System.out.println("Handling fortune request: " + messageASM.getContentASM());
           handleChatMessage(messageASM);
       }
       
       private void handleLoginRequest(Message messageASM) throws IOException {
           User userASM = messageASM.getUserASM();
           System.out.println("Login request from user: " + userASM.getUsernameASM());
           
           User authenticatedUserASM = userDAOASM.authenticateUser(
               userASM.getUsernameASM(), userASM.getPasswordASM());
           
           boolean successASM = (authenticatedUserASM != null);
           String contentASM = successASM ? "Login successful" : "Invalid username or password";
           System.out.println("Login result: " + contentASM);
           
           Message responseASM = new Message(Message.LOGIN_RESPONSE, contentASM, successASM);
           if (successASM) {
               responseASM.setUserASM(authenticatedUserASM);
               currentUserASM = authenticatedUserASM;
               
               sendInitialGreeting();
           }
           
           outputASM.writeObject(responseASM);
           outputASM.flush();
       }
       
       private void handleSignupRequest(Message messageASM) throws IOException {
           User userASM = messageASM.getUserASM();
           System.out.println("Signup request for user: " + userASM.getUsernameASM());
           
           boolean successASM = userDAOASM.registerUser(userASM);
           
           String contentASM = successASM ? "Registration successful" : "Username already exists";
           System.out.println("Signup result: " + contentASM);
           
           Message responseASM = new Message(Message.SIGNUP_RESPONSE, contentASM, successASM);
           if (successASM) {
               responseASM.setUserASM(userASM);
               currentUserASM = userASM;
               
               sendInitialGreeting();
           }
           
           outputASM.writeObject(responseASM);
           outputASM.flush();
       }
       
       private void sendInitialGreeting() throws IOException {
           if (currentUserASM != null) {
               String greetingASM = "Hello, " + currentUserASM.getUsernameASM() + ". Are you having a good day?";
               System.out.println("Sending greeting: " + greetingASM);
               
               Message greetingMessageASM = new Message(Message.CHAT_MESSAGE, greetingASM);
               
               outputASM.writeObject(greetingMessageASM);
               outputASM.flush();
           }
       }
       
       private void handleChatMessage(Message messageASM) throws IOException {
           String messageContentASM = messageASM.getContentASM().trim().toLowerCase();
           System.out.println("Handling chat message: " + messageContentASM);
           
           if (guiASM != null) {
               guiASM.resetWordCounts();
           }
           
           if (messageContentASM.equals("yes") || messageContentASM.equals("no")) {
               if (messageContentASM.equals("yes")) {
                   sendConsultingMessage();
                   
                   try {
                       Thread.sleep(5000);
                   } catch (InterruptedException e) {
                       Thread.currentThread().interrupt();
                   }
                   
                   sendFortune();
               } else {
                   String goodbyeASM = "Thank you for consulting with me. Have a wonderful day!";
                   Message goodbyeMessageASM = new Message(Message.CHAT_MESSAGE, goodbyeASM);
                   
                   outputASM.writeObject(goodbyeMessageASM);
                   outputASM.flush();
               }
           } else {
               sendConsultingMessage();
               
               int positiveCountASM = sentimentAnalyzerASM.countPositiveWords(messageContentASM);
               int negativeCountASM = sentimentAnalyzerASM.countNegativeWords(messageContentASM);
               
               System.out.println("Sentiment analysis - Positive: " + positiveCountASM + ", Negative: " + negativeCountASM);
               
               if (guiASM != null) {
                   guiASM.updateWordCounts(positiveCountASM, negativeCountASM);
               }
               
               try {
                   Thread.sleep(5000);
               } catch (InterruptedException e) {
                   Thread.currentThread().interrupt();
               }
               
               sendFortune(positiveCountASM, negativeCountASM);
               
               new Thread(() -> {
                   try {
                       Thread.sleep(5000);
                       
                       String followUpASM = "Do you want me to try again? Yes or No?";
                       Message followUpMessageASM = new Message(Message.CHAT_MESSAGE, followUpASM);
                       
                       System.out.println("Sending follow-up: " + followUpASM);
                       outputASM.writeObject(followUpMessageASM);
                       outputASM.flush();
                   } catch (InterruptedException e) {
                       Thread.currentThread().interrupt();
                   } catch (IOException e) {
                       System.err.println("Error sending follow-up message: " + e.getMessage());
                   }
               }).start();
           }
       }
       
       private void sendConsultingMessage() throws IOException {
           String consultingASM = "Ok, give me a minute to consult my crystal ball.";
           System.out.println("Sending consulting message: " + consultingASM);
           
           Message consultingMessageASM = new Message(Message.CHAT_MESSAGE, consultingASM);
           
           outputASM.writeObject(consultingMessageASM);
           outputASM.flush();
       }
       
       private void sendFortune() throws IOException {
           int positiveCountASM = 0;
           int negativeCountASM = 0;
           
           if (guiASM != null) {
               try {
                   positiveCountASM = Integer.parseInt(guiASM.getPositiveWordCount());
                   negativeCountASM = Integer.parseInt(guiASM.getNegativeWordCount());
               } catch (NumberFormatException e) {
                   System.err.println("Error parsing word counts: " + e.getMessage());
               }
           }
           
           sendFortune(positiveCountASM, negativeCountASM);
       }
       
       private void sendFortune(int positiveCountASM, int negativeCountASM) throws IOException {
           Fortune fortuneASM;
           
           if (positiveCountASM > negativeCountASM) {
               Random randomASM = new Random();
               if (randomASM.nextBoolean()) {
                   fortuneASM = fortuneDAOASM.getRandomFortune("positive");
               } else {
                   fortuneASM = fortuneDAOASM.getRandomFortune("negative");
               }
           } else if (negativeCountASM > positiveCountASM) {
               fortuneASM = fortuneDAOASM.getRandomFortune("positive");
           } else {
               fortuneASM = fortuneDAOASM.getRandomFortune();
           }
           
           String fortuneResponseASM = "I see " + fortuneASM.getContentASM() + " in your future.";
           System.out.println("Sending fortune: " + fortuneResponseASM);
           
           Message fortuneMessageASM = new Message(Message.CHAT_MESSAGE, fortuneResponseASM);
           
           outputASM.writeObject(fortuneMessageASM);
           outputASM.flush();
       }
       
       private void closeConnection() {
           clientConnectedASM = false;
           System.out.println("Closing client connection");
           
           try {
               if (outputASM != null) {
                   outputASM.close();
               }
               if (inputASM != null) {
                   inputASM.close();
               }
               if (clientSocketASM != null && !clientSocketASM.isClosed()) {
                   clientSocketASM.close();
               }
           } catch (IOException e) {
               System.err.println("Error closing client connection: " + e.getMessage());
           }
           
           if (guiASM != null) {
               guiASM.updateConnectionStatus(false);
               guiASM.resetWordCounts();
           }
       }
   }
   
   public static void main(String[] args) {
       javax.swing.SwingUtilities.invokeLater(() -> {
           ServerGUI serverGUIASM = new ServerGUI();
           serverGUIASM.setVisible(true);
           
           FortuneServer server = new FortuneServer(serverGUIASM);
           
           new Thread(() -> {
               server.startServer();
           }).start();
           
           if (serverGUIASM != null) {
               serverGUIASM.setServer(server);
           }
       });
   }
}