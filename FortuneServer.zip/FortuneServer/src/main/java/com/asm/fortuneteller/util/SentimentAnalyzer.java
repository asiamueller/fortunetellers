package com.asm.fortuneteller.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SentimentAnalyzer {
    private Set<String> positiveWordsASM;
    private Set<String> negativeWordsASM;
    
    public SentimentAnalyzer() {
        positiveWordsASM = new HashSet<>();
        negativeWordsASM = new HashSet<>();
        loadWordLists();
    }
    
    private void loadWordLists() {
        // Load positive words
        try (BufferedReader readerASM = new BufferedReader(
                new InputStreamReader(getClass().getResourceAsStream("/positive_words.txt")))) {
            String lineASM;
            while ((lineASM = readerASM.readLine()) != null) {
                lineASM = lineASM.trim().toLowerCase();
                if (!lineASM.isEmpty() && !lineASM.startsWith("#")) {
                    positiveWordsASM.add(lineASM);
                }
            }
        } catch (IOException | NullPointerException e) {
            System.err.println("Error loading positive words: " + e.getMessage());
            // Fallback to a basic list if file not found
            positiveWordsASM.addAll(Arrays.asList(
                "good", "great", "happy", "excited", "love", "awesome", "amazing", "excellent", 
                "wonderful", "fantastic", "joy", "delighted", "positive", "nice", "best", "fun", 
                "beautiful", "lucky", "pleased", "glad"
            ));
        }
        
        // Load negative words
        try (BufferedReader readerASM = new BufferedReader(
                new InputStreamReader(getClass().getResourceAsStream("/negative_words.txt")))) {
            String lineASM;
            while ((lineASM = readerASM.readLine()) != null) {
                lineASM = lineASM.trim().toLowerCase();
                if (!lineASM.isEmpty() && !lineASM.startsWith("#")) {
                    negativeWordsASM.add(lineASM);
                }
            }
        } catch (IOException | NullPointerException e) {
            System.err.println("Error loading negative words: " + e.getMessage());
            // Fallback to a basic list if file not found
            negativeWordsASM.addAll(Arrays.asList(
                "bad", "sad", "angry", "upset", "hate", "terrible", "horrible", "awful", 
                "disappointing", "worst", "unhappy", "miserable", "negative", "annoyed", 
                "depressed", "frustrated", "dislike", "unfortunate", "lost", "worried"
            ));
        }
    }
    
    public int countPositiveWords(String textASM) {
        if (textASM == null || textASM.isEmpty()) {
            return 0;
        }
        
        String[] wordsASM = textASM.toLowerCase().replaceAll("[^a-zA-Z0-9\\s]", "").split("\\s+");
        int countASM = 0;
        
        for (String wordASM : wordsASM) {
            if (positiveWordsASM.contains(wordASM)) {
                countASM++;
            }
        }
        
        return countASM;
    }
    
    public int countNegativeWords(String textASM) {
        if (textASM == null || textASM.isEmpty()) {
            return 0;
        }
        
        String[] wordsASM = textASM.toLowerCase().replaceAll("[^a-zA-Z0-9\\s]", "").split("\\s+");
        int countASM = 0;
        
        for (String wordASM : wordsASM) {
            if (negativeWordsASM.contains(wordASM)) {
                countASM++;
            }
        }
        
        return countASM;
    }
    
    public List<String> getFoundPositiveWords(String textASM) {
        if (textASM == null || textASM.isEmpty()) {
            return new ArrayList<>();
        }
        
        String[] wordsASM = textASM.toLowerCase().replaceAll("[^a-zA-Z0-9\\s]", "").split("\\s+");
        List<String> foundWordsASM = new ArrayList<>();
        
        for (String wordASM : wordsASM) {
            if (positiveWordsASM.contains(wordASM) && !foundWordsASM.contains(wordASM)) {
                foundWordsASM.add(wordASM);
            }
        }
        
        return foundWordsASM;
    }
    
    public List<String> getFoundNegativeWords(String textASM) {
        if (textASM == null || textASM.isEmpty()) {
            return new ArrayList<>();
        }
        
        String[] wordsASM = textASM.toLowerCase().replaceAll("[^a-zA-Z0-9\\s]", "").split("\\s+");
        List<String> foundWordsASM = new ArrayList<>();
        
        for (String wordASM : wordsASM) {
            if (negativeWordsASM.contains(wordASM) && !foundWordsASM.contains(wordASM)) {
                foundWordsASM.add(wordASM);
            }
        }
        
        return foundWordsASM;
    }
}