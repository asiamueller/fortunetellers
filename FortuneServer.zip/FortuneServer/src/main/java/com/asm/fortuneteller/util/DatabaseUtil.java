package com.asm.fortuneteller.util;

import java.sql.*;

public class DatabaseUtil {
    private static final String DB_URL_ASM = "jdbc:sqlite:fortuneteller.db";
    private static Connection connectionASM;
    
    public static Connection getConnection() throws SQLException {
        if (connectionASM == null || connectionASM.isClosed()) {
            try {
                Class.forName("org.sqlite.JDBC");
                connectionASM = DriverManager.getConnection(DB_URL_ASM);
                connectionASM.setAutoCommit(true);
            } catch (ClassNotFoundException e) {
                throw new SQLException("SQLite JDBC driver not found", e);
            }
        }
        return connectionASM;
    }
    
    public static void closeConnection() {
        try {
            if (connectionASM != null && !connectionASM.isClosed()) {
                connectionASM.close();
            }
        } catch (SQLException e) {
            System.err.println("Error closing database connection: " + e.getMessage());
        }
    }
    
    public static void closeResources(Connection conn, Statement stmt, ResultSet rs) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                System.err.println("Error closing ResultSet: " + e.getMessage());
            }
        }
        
        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException e) {
                System.err.println("Error closing Statement: " + e.getMessage());
            }
        }
        
        if (conn != null && conn != connectionASM) {
            try {
                conn.close();
            } catch (SQLException e) {
                System.err.println("Error closing Connection: " + e.getMessage());
            }
        }
    }
}