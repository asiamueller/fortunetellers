package com.asm.fortuneteller.gui;

import com.asm.fortuneteller.fortuneserver.FortuneServer;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;

public class ServerGUI extends JFrame {
    private JTextField connectionStatusFieldASM;
    private JTextField positiveWordCountFieldASM;
    private JTextField negativeWordCountFieldASM;
    private FortuneServer serverASM;
    private JLabel footerLabelASM; 
    
    public ServerGUI() {
        setTitle("ASM's Excellent Fortune Teller - Server");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 300);
        setLocationRelativeTo(null);
        
        JPanel mainPanelASM = new JPanel();
        mainPanelASM.setLayout(new BorderLayout(10, 10));
        mainPanelASM.setBorder(new EmptyBorder(20, 20, 20, 20));
        mainPanelASM.setBackground(new Color(230, 230, 250));
        
        JLabel headerLabelASM = new JLabel("Fortune Teller Server", SwingConstants.CENTER);
        headerLabelASM.setFont(new Font("Arial", Font.BOLD, 24));
        headerLabelASM.setForeground(new Color(75, 0, 130));
        mainPanelASM.add(headerLabelASM, BorderLayout.NORTH);
        
        JPanel statusPanelASM = new JPanel(new GridLayout(3, 2, 10, 20));
        statusPanelASM.setBackground(new Color(230, 230, 250));
        statusPanelASM.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        
        JLabel connectionLabelASM = new JLabel("Connection Status:", SwingConstants.RIGHT);
        connectionLabelASM.setFont(new Font("Arial", Font.BOLD, 14));
        connectionStatusFieldASM = new JTextField("Not connected");
        connectionStatusFieldASM.setFont(new Font("Arial", Font.PLAIN, 14));
        connectionStatusFieldASM.setEditable(false);
        connectionStatusFieldASM.setBackground(Color.WHITE);
        connectionStatusFieldASM.setHorizontalAlignment(JTextField.CENTER);
        
        JLabel positiveWordLabelASM = new JLabel("Positive Word Count:", SwingConstants.RIGHT);
        positiveWordLabelASM.setFont(new Font("Arial", Font.BOLD, 14));
        positiveWordCountFieldASM = new JTextField("0");
        positiveWordCountFieldASM.setFont(new Font("Arial", Font.PLAIN, 14));
        positiveWordCountFieldASM.setEditable(false);
        positiveWordCountFieldASM.setBackground(Color.WHITE);
        positiveWordCountFieldASM.setHorizontalAlignment(JTextField.CENTER);
        
        JLabel negativeWordLabelASM = new JLabel("Negative Word Count:", SwingConstants.RIGHT);
        negativeWordLabelASM.setFont(new Font("Arial", Font.BOLD, 14));
        negativeWordCountFieldASM = new JTextField("0");
        negativeWordCountFieldASM.setFont(new Font("Arial", Font.PLAIN, 14));
        negativeWordCountFieldASM.setEditable(false);
        negativeWordCountFieldASM.setBackground(Color.WHITE);
        negativeWordCountFieldASM.setHorizontalAlignment(JTextField.CENTER);
        
        statusPanelASM.add(connectionLabelASM);
        statusPanelASM.add(connectionStatusFieldASM);
        statusPanelASM.add(positiveWordLabelASM);
        statusPanelASM.add(positiveWordCountFieldASM);
        statusPanelASM.add(negativeWordLabelASM);
        statusPanelASM.add(negativeWordCountFieldASM);
        
        mainPanelASM.add(statusPanelASM, BorderLayout.CENTER);
        
        footerLabelASM = new JLabel("Server running on port 5555", SwingConstants.CENTER);
        footerLabelASM.setFont(new Font("Arial", Font.ITALIC, 12));
        mainPanelASM.add(footerLabelASM, BorderLayout.SOUTH);
        
        add(mainPanelASM);
    }
    
    public void startServer() {
        serverASM = new FortuneServer(this);
        new Thread(() -> serverASM.startServer()).start();
        setVisible(true);
    }
    
    public void updateConnectionStatus(boolean connectedASM) {
        SwingUtilities.invokeLater(() -> {
            if (connectedASM) {
                connectionStatusFieldASM.setText("Connected");
                connectionStatusFieldASM.setForeground(new Color(0, 128, 0));
            } else {
                connectionStatusFieldASM.setText("Not connected");
                connectionStatusFieldASM.setForeground(Color.RED);
            }
        });
    }
    
    public void updateWordCounts(int positiveASM, int negativeASM) {
        SwingUtilities.invokeLater(() -> {
            positiveWordCountFieldASM.setText(String.valueOf(positiveASM));
            negativeWordCountFieldASM.setText(String.valueOf(negativeASM));
        });
    }
    
    public void resetWordCounts() {
        SwingUtilities.invokeLater(() -> {
            positiveWordCountFieldASM.setText("0");
            negativeWordCountFieldASM.setText("0");
        });
    }
    
    public String getPositiveWordCount() {
        return positiveWordCountFieldASM.getText();
    }
    
    public String getNegativeWordCount() {
        return negativeWordCountFieldASM.getText();
    }
    
    public void updateServerStatus(String status) {
        SwingUtilities.invokeLater(() -> {
            footerLabelASM.setText(status);
        });
    }
    
    public void setServer(FortuneServer server) {
        this.serverASM = server;
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ServerGUI gui = new ServerGUI();
            gui.startServer();
        });
    }
}