package com.asm.fortuneteller.model;

import java.io.Serializable;

public class User implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private int idASM;
    private String usernameASM;
    private String passwordASM;
    
    public User() {
    }
    
    public User(String usernameASM, String passwordASM) {
        this.usernameASM = usernameASM;
        this.passwordASM = passwordASM;
    }
    
    public User(int idASM, String usernameASM, String passwordASM) {
        this.idASM = idASM;
        this.usernameASM = usernameASM;
        this.passwordASM = passwordASM;
    }
    
    public int getIdASM() {
        return idASM;
    }
    
    public void setIdASM(int idASM) {
        this.idASM = idASM;
    }
    
    public String getUsernameASM() {
        return usernameASM;
    }
    
    public void setUsernameASM(String usernameASM) {
        this.usernameASM = usernameASM;
    }
    
    public String getPasswordASM() {
        return passwordASM;
    }
    
    public void setPasswordASM(String passwordASM) {
        this.passwordASM = passwordASM;
    }
}