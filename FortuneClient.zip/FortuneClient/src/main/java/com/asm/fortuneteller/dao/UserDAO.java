package com.asm.fortuneteller.dao;

import com.asm.fortuneteller.model.User;
import com.asm.fortuneteller.util.DatabaseUtil;

import java.sql.*;

public class UserDAO {
    
    public boolean registerUser(User userASM) {
        Connection connASM = null;
        PreparedStatement stmtASM = null;
        ResultSet rsASM = null;
        boolean successASM = false;
        
        try {
            connASM = DatabaseUtil.getConnection();
            
            // Check if username already exists
            String checkSqlASM = "SELECT COUNT(*) FROM users WHERE username = ?";
            stmtASM = connASM.prepareStatement(checkSqlASM);
            stmtASM.setString(1, userASM.getUsernameASM());
            rsASM = stmtASM.executeQuery();
            
            if (rsASM.next() && rsASM.getInt(1) > 0) {
                return false; // Username already exists
            }
            
            // Close the previous resources
            DatabaseUtil.closeResources(null, stmtASM, rsASM);
            
            // Insert new user
            String insertSqlASM = "INSERT INTO users (username, password) VALUES (?, ?)";
            stmtASM = connASM.prepareStatement(insertSqlASM, Statement.RETURN_GENERATED_KEYS);
            stmtASM.setString(1, userASM.getUsernameASM());
            stmtASM.setString(2, userASM.getPasswordASM());
            
            int rowsAffectedASM = stmtASM.executeUpdate();
            if (rowsAffectedASM > 0) {
                rsASM = stmtASM.getGeneratedKeys();
                if (rsASM.next()) {
                    userASM.setIdASM(rsASM.getInt(1));
                    successASM = true;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error registering user: " + e.getMessage());
        } finally {
            DatabaseUtil.closeResources(connASM, stmtASM, rsASM);
        }
        
        return successASM;
    }
    
    public User authenticateUser(String usernameASM, String passwordASM) {
        Connection connASM = null;
        PreparedStatement stmtASM = null;
        ResultSet rsASM = null;
        User userASM = null;
        
        try {
            connASM = DatabaseUtil.getConnection();
            String sqlASM = "SELECT id, username, password FROM users WHERE username = ? AND password = ?";
            stmtASM = connASM.prepareStatement(sqlASM);
            stmtASM.setString(1, usernameASM);
            stmtASM.setString(2, passwordASM);
            rsASM = stmtASM.executeQuery();
            
            if (rsASM.next()) {
                userASM = new User(
                    rsASM.getInt("id"),
                    rsASM.getString("username"),
                    rsASM.getString("password")
                );
            }
        } catch (SQLException e) {
            System.err.println("Error authenticating user: " + e.getMessage());
        } finally {
            DatabaseUtil.closeResources(connASM, stmtASM, rsASM);
        }
        
        return userASM;
    }
    
    // Initialize the users table if it doesn't exist
    public void initializeTable() {
        Connection connASM = null;
        Statement stmtASM = null;
        
        try {
            connASM = DatabaseUtil.getConnection();
            stmtASM = connASM.createStatement();
            
            // Create users table if it doesn't exist
            String createTableSqlASM = 
                "CREATE TABLE IF NOT EXISTS users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE NOT NULL, " +
                "password TEXT NOT NULL)";
            
            stmtASM.executeUpdate(createTableSqlASM);
        } catch (SQLException e) {
            System.err.println("Error initializing users table: " + e.getMessage());
        } finally {
            DatabaseUtil.closeResources(connASM, stmtASM, null);
        }
    }
}