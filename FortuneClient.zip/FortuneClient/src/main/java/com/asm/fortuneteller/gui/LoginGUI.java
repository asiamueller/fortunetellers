package com.asm.fortuneteller.gui;

import com.asm.fortuneteller.fortuneclient.FortuneClient;
import com.asm.fortuneteller.model.User;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class LoginGUI extends JFrame {
    private JTextField usernameFieldASM;
    private JPasswordField passwordFieldASM;
    private JButton loginButtonASM;
    private JButton signupButtonASM;
    private FortuneClient clientASM;
    
    public LoginGUI() {
        setTitle("ASM's Excellent Fortune Teller - Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 350);
        setLocationRelativeTo(null);
        
        clientASM = new FortuneClient();
        if (!clientASM.connectToServer()) {
            JOptionPane.showMessageDialog(this, 
                "Could not connect to the server. Please make sure the server is running.",
                "Connection Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
        
        JPanel mainPanelASM = new JPanel();
        mainPanelASM.setLayout(new BorderLayout(10, 10));
        mainPanelASM.setBorder(new EmptyBorder(20, 20, 20, 20));
        mainPanelASM.setBackground(new Color(230, 230, 250));
        
        JLabel headerLabelASM = new JLabel("Fortune Teller", SwingConstants.CENTER);
        headerLabelASM.setFont(new Font("Arial", Font.BOLD, 24));
        headerLabelASM.setForeground(new Color(75, 0, 130));
        mainPanelASM.add(headerLabelASM, BorderLayout.NORTH);
        
        JPanel loginPanelASM = new JPanel(new GridBagLayout());
        loginPanelASM.setBackground(new Color(230, 230, 250));
        loginPanelASM.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        
        GridBagConstraints gbcASM = new GridBagConstraints();
        gbcASM.fill = GridBagConstraints.HORIZONTAL;
        gbcASM.insets = new Insets(5, 5, 5, 5);
        
        JLabel usernameLabelASM = new JLabel("Username:", SwingConstants.RIGHT);
        usernameLabelASM.setFont(new Font("Arial", Font.BOLD, 14));
        gbcASM.gridx = 0;
        gbcASM.gridy = 0;
        gbcASM.gridwidth = 1;
        loginPanelASM.add(usernameLabelASM, gbcASM);
        
        usernameFieldASM = new JTextField(15);
        usernameFieldASM.setFont(new Font("Arial", Font.PLAIN, 14));
        usernameFieldASM.setToolTipText("Enter your username");
        gbcASM.gridx = 1;
        gbcASM.gridy = 0;
        gbcASM.gridwidth = 2;
        loginPanelASM.add(usernameFieldASM, gbcASM);
        
        JLabel passwordLabelASM = new JLabel("Password:", SwingConstants.RIGHT);
        passwordLabelASM.setFont(new Font("Arial", Font.BOLD, 14));
        gbcASM.gridx = 0;
        gbcASM.gridy = 1;
        gbcASM.gridwidth = 1;
        loginPanelASM.add(passwordLabelASM, gbcASM);
        
        passwordFieldASM = new JPasswordField(15);
        passwordFieldASM.setFont(new Font("Arial", Font.PLAIN, 14));
        passwordFieldASM.setToolTipText("Enter your password");
        gbcASM.gridx = 1;
        gbcASM.gridy = 1;
        gbcASM.gridwidth = 2;
        loginPanelASM.add(passwordFieldASM, gbcASM);
        
        JPanel buttonPanelASM = new JPanel();
        buttonPanelASM.setBackground(new Color(230, 230, 250));
        
        loginButtonASM = new JButton("Login");
        loginButtonASM.setFont(new Font("Arial", Font.BOLD, 14));
        loginButtonASM.setBackground(new Color(147, 112, 219));
        loginButtonASM.setForeground(Color.magenta);
        loginButtonASM.setPreferredSize(new Dimension(100, 30));
        loginButtonASM.setToolTipText("Click to login");
        
        signupButtonASM = new JButton("Sign Up");
        signupButtonASM.setFont(new Font("Arial", Font.BOLD, 14));
        signupButtonASM.setBackground(new Color(75, 0, 130));
        signupButtonASM.setForeground(Color.magenta);
        signupButtonASM.setPreferredSize(new Dimension(100, 30));
        signupButtonASM.setToolTipText("Click to create a new account");
        
        buttonPanelASM.add(loginButtonASM);
        buttonPanelASM.add(signupButtonASM);
        
        gbcASM.gridx = 0;
        gbcASM.gridy = 2;
        gbcASM.gridwidth = 3;
        gbcASM.insets = new Insets(20, 5, 5, 5);
        loginPanelASM.add(buttonPanelASM, gbcASM);
        
        mainPanelASM.add(loginPanelASM, BorderLayout.CENTER);
        
        JLabel footerLabelASM = new JLabel("Enter your credentials to continue", SwingConstants.CENTER);
        footerLabelASM.setFont(new Font("Arial", Font.ITALIC, 12));
        mainPanelASM.add(footerLabelASM, BorderLayout.SOUTH);
        
        add(mainPanelASM);
        
        loginButtonASM.addActionListener(e -> login());
        signupButtonASM.addActionListener(e -> signup());
        
        passwordFieldASM.addActionListener(e -> login());
    }
    
    private void login() {
        String usernameASM = usernameFieldASM.getText().trim();
        String passwordASM = new String(passwordFieldASM.getPassword());
        
        if (usernameASM.isEmpty() || passwordASM.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please enter both username and password.",
                "Login Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        User userASM = new User(usernameASM, passwordASM);
        boolean successASM = clientASM.login(userASM);
        
        if (successASM) {
            openChatWindow(userASM);
        } else {
            JOptionPane.showMessageDialog(this, 
                "Invalid username or password. Please try again.",
                "Login Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void signup() {
        String usernameASM = usernameFieldASM.getText().trim();
        String passwordASM = new String(passwordFieldASM.getPassword());
        
        if (usernameASM.isEmpty() || passwordASM.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please enter both username and password.",
                "Sign Up Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        User userASM = new User(usernameASM, passwordASM);
        boolean successASM = clientASM.signup(userASM);
        
        if (successASM) {
            openChatWindow(userASM);
        } else {
            JOptionPane.showMessageDialog(this, 
                "Username already exists. Please choose a different username.",
                "Sign Up Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void openChatWindow(User userASM) {
        this.dispose(); 
        
        ChatGUI chatGUIASM = new ChatGUI(clientASM, userASM);
        chatGUIASM.setVisible(true);
    }
    
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> {
            new LoginGUI().setVisible(true);
        });
    }
}