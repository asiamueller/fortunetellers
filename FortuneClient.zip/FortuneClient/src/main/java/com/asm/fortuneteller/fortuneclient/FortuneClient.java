package com.asm.fortuneteller.fortuneclient;

import com.asm.fortuneteller.model.Message;
import com.asm.fortuneteller.model.User;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ConnectException;
import java.net.Socket;
import java.net.InetSocketAddress;
import java.net.SocketTimeoutException;
import java.util.function.Consumer;

/**
 * Client for connecting to the Fortune Teller server
 * @author asiasymo
 */
public class FortuneClient {
    private Socket socketASM;
    private ObjectOutputStream outputASM;
    private ObjectInputStream inputASM;
    private Consumer<Message> messageListener;
    private boolean connectedASM = false;
    private MessageReceiver receiverASM;
    
    private static final String SERVER_ADDRESS = "localhost";
    private static final int SERVER_PORT = 5555; 
    private static final int CONNECTION_TIMEOUT = 5000;
    
    /**
     * Connect to the fortune teller server
     * @return true if connection successful, false otherwise
     */
    public boolean connectToServer() {
        try {
            System.out.println("Attempting to connect to server at " + SERVER_ADDRESS + ":" + SERVER_PORT);
            
            socketASM = new Socket();
            socketASM.connect(new InetSocketAddress(SERVER_ADDRESS, SERVER_PORT), CONNECTION_TIMEOUT);
            
            System.out.println("Socket connected: " + socketASM.isConnected());
            
            outputASM = new ObjectOutputStream(socketASM.getOutputStream());
            inputASM = new ObjectInputStream(socketASM.getInputStream());
            connectedASM = true;
            
            System.out.println("Connection established successfully");
            
            receiverASM = new MessageReceiver();
            receiverASM.start();
            
            return true;
        } catch (ConnectException e) {
            System.err.println("Connection refused. Make sure the server is running: " + e.getMessage());
            return false;
        } catch (SocketTimeoutException e) {
            System.err.println("Connection timed out. Server may be unavailable: " + e.getMessage());
            return false;
        } catch (IOException e) {
            System.err.println("Error connecting to server: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Disconnect from the server
     */
    public void disconnect() {
        try {
            if (connectedASM) {
                System.out.println("Disconnecting from server");
                
                Message disconnectMsg = new Message(Message.DISCONNECT, "Client disconnecting");
                sendObject(disconnectMsg);
                
                if (inputASM != null) inputASM.close();
                if (outputASM != null) outputASM.close();
                if (socketASM != null) socketASM.close();
                
                connectedASM = false;
                
                if (receiverASM != null) {
                    receiverASM.stopRunning();
                }
                
                System.out.println("Disconnected from server");
            }
        } catch (IOException e) {
            System.err.println("Error disconnecting: " + e.getMessage());
        }
    }
    
    /**
     * Attempt to login with user credentials
     * @param user The user to login
     * @return true if login successful, false otherwise
     */
    public boolean login(User user) {
        if (!connectedASM) {
            System.err.println("Cannot login: Not connected to server");
            return false;
        }
        
        try {
            System.out.println("Sending login request for user: " + user.getUsernameASM());
            
            Message loginRequest = new Message(Message.LOGIN_REQUEST, "Login request", user);
            
            sendObject(loginRequest);
            
            System.out.println("Login request sent successfully");
            
            
            return true;
        } catch (Exception e) {
            System.err.println("Error during login: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Sign up a new user
     * @param user The user to sign up
     * @return true if signup successful, false otherwise
     */
    public boolean signup(User user) {
        if (!connectedASM) {
            System.err.println("Cannot signup: Not connected to server");
            return false;
        }
        
        try {
            System.out.println("Sending signup request for user: " + user.getUsernameASM());
            
            Message signupRequest = new Message(Message.SIGNUP_REQUEST, "Signup request", user);
            
            sendObject(signupRequest);
            
            System.out.println("Signup request sent successfully");
            
            
            return true;
        } catch (Exception e) {
            System.err.println("Error during signup: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Send a message to the server
     * @param messageContent The message content to send
     * @return true if message sent successfully, false otherwise
     */
    public boolean sendMessage(String messageContent) {
        if (!connectedASM) {
            System.err.println("Cannot send message: Not connected to server");
            return false;
        }
        
        try {
            System.out.println("Sending message: " + messageContent);
            
            Message fortuneRequest = new Message(Message.FORTUNE_REQUEST, messageContent);
            
            sendObject(fortuneRequest);
            
            System.out.println("Message sent successfully");
            return true;
        } catch (Exception e) {
            System.err.println("Error sending message: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Helper method to send an object to the server
     * @param message The message to send
     * @throws IOException If an I/O error occurs
     */
    private void sendObject(Message message) throws IOException {
        if (outputASM != null) {
            outputASM.writeObject(message);
            outputASM.flush();
        } else {
            throw new IOException("Output stream is not initialized");
        }
    }
    
    /**
     * Set a listener for incoming messages
     * @param listener Consumer that will handle incoming messages
     */
    public void setMessageListener(Consumer<Message> listener) {
        this.messageListener = listener;
    }
    
    /**
     * Inner class to handle receiving messages from the server
     */
    private class MessageReceiver extends Thread {
        private boolean runningASM = true;
        
        @Override
        public void run() {
            System.out.println("Message receiver thread started");
            
            while (runningASM && connectedASM) {
                try {
                    Message message = (Message) inputASM.readObject();
                    
                    if (message != null) {
                        System.out.println("Received message from server: Type=" + message.getTypeASM() + 
                                          ", Content=" + message.getContentASM());
                        
                        if (messageListener != null) {
                            messageListener.accept(message);
                        }
                    }
                } catch (IOException e) {
                    if (runningASM) {
                        System.err.println("Connection to server lost: " + e.getMessage());
                        connectedASM = false;
                        
                        if (messageListener != null) {
                            Message disconnectMsg = new Message(Message.ERROR, "Connection to server lost");
                            messageListener.accept(disconnectMsg);
                        }
                    }
                    break;
                } catch (ClassNotFoundException e) {
                    System.err.println("Error receiving message: " + e.getMessage());
                }
            }
            
            System.out.println("Message receiver thread stopped");
        }
        
        /**
         * Stop the receiver thread
         */
        public void stopRunning() {
            System.out.println("Stopping message receiver thread");
            runningASM = false;
            this.interrupt();
        }
    }
    
    /**
     * Check if client is connected to server
     * @return true if connected, false otherwise
     */
    public boolean isConnected() {
        return connectedASM && socketASM != null && socketASM.isConnected() && !socketASM.isClosed();
    }
}