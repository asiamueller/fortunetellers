package com.asm.fortuneteller.model;

import java.io.Serializable;

public class Message implements Serializable {
    private static final long serialVersionUID = 1L;
    
    public static final int LOGIN_REQUEST = 1;
    public static final int LOGIN_RESPONSE = 2;
    public static final int SIGNUP_REQUEST = 3;
    public static final int SIGNUP_RESPONSE = 4;
    public static final int CHAT_MESSAGE = 5;
    public static final int FORTUNE_REQUEST = 6;
    public static final int FORTUNE_RESPONSE = 7;
    public static final int DISCONNECT = 8;
    public static final int ERROR = 9; 
    
    private int typeASM;
    private String contentASM;
    private User userASM;
    private boolean successASM;
    
    public Message() {
    }
    
    public Message(int typeASM, String contentASM) {
        this.typeASM = typeASM;
        this.contentASM = contentASM;
    }
    
    public Message(int typeASM, String contentASM, User userASM) {
        this.typeASM = typeASM;
        this.contentASM = contentASM;
        this.userASM = userASM;
    }
    
    public Message(int typeASM, String contentASM, boolean successASM) {
        this.typeASM = typeASM;
        this.contentASM = contentASM;
        this.successASM = successASM;
    }
    
    public int getTypeASM() {
        return typeASM;
    }
    
    public void setTypeASM(int typeASM) {
        this.typeASM = typeASM;
    }
    
    public String getContentASM() {
        return contentASM;
    }
    
    public void setContentASM(String contentASM) {
        this.contentASM = contentASM;
    }
    
    public User getUserASM() {
        return userASM;
    }
    
    public void setUserASM(User userASM) {
        this.userASM = userASM;
    }
    
    public boolean isSuccessASM() {
        return successASM;
    }
    
    public void setSuccessASM(boolean successASM) {
        this.successASM = successASM;
    }
}