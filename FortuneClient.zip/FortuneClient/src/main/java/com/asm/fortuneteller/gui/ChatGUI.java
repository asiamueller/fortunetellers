package com.asm.fortuneteller.gui;

import com.asm.fortuneteller.fortuneclient.FortuneClient;
import com.asm.fortuneteller.model.Message;
import com.asm.fortuneteller.model.User;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.text.AttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;
import javax.swing.text.StyledDocument;
import javax.swing.JTextPane;

public class ChatGUI extends JFrame {
    private JTextPane conversationPaneASM;
    private JTextField messageFieldASM;
    private JButton sendButtonASM;
    private JButton clearButtonASM;
    private JToggleButton speechToggleASM;
    private FortuneClient clientASM;
    private User userASM;
    
    public ChatGUI(FortuneClient clientASM, User userASM) {
        this.clientASM = clientASM;
        this.userASM = userASM;
        
        setTitle("ASM's Excellent Fortune Teller - Chat");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 500);
        setLocationRelativeTo(null);
        
        clientASM.setMessageListener(this::handleIncomingMessage);
        
        JPanel mainPanelASM = new JPanel();
        mainPanelASM.setLayout(new BorderLayout(10, 10));
        mainPanelASM.setBorder(new EmptyBorder(20, 20, 20, 20));
        mainPanelASM.setBackground(new Color(230, 230, 250));
        
        conversationPaneASM = new JTextPane();
        conversationPaneASM.setEditable(false);
        conversationPaneASM.setFont(new Font("Arial", Font.PLAIN, 14));
        conversationPaneASM.setBackground(Color.WHITE);
        
        JScrollPane scrollPaneASM = new JScrollPane(conversationPaneASM);
        scrollPaneASM.setPreferredSize(new Dimension(550, 350));
        scrollPaneASM.setBorder(BorderFactory.createLineBorder(new Color(147, 112, 219), 2));
        
        JPanel inputPanelASM = new JPanel();
        inputPanelASM.setLayout(new BorderLayout(5, 0));
        inputPanelASM.setBackground(new Color(230, 230, 250));
        
        messageFieldASM = new JTextField();
        messageFieldASM.setFont(new Font("Arial", Font.PLAIN, 14));
        
        JPanel buttonPanelASM = new JPanel();
        buttonPanelASM.setBackground(new Color(230, 230, 250));
        
        sendButtonASM = new JButton("Send");
        sendButtonASM.setFont(new Font("Arial", Font.BOLD, 14));
        sendButtonASM.setBackground(new Color(147, 112, 219));
        sendButtonASM.setForeground(Color.magenta);
        sendButtonASM.setToolTipText("Send your message");
        
        clearButtonASM = new JButton("Clear");
        clearButtonASM.setFont(new Font("Arial", Font.BOLD, 14));
        clearButtonASM.setBackground(new Color(75, 0, 130));
        clearButtonASM.setForeground(Color.magenta);
        clearButtonASM.setToolTipText("Clear the message field");
        
        speechToggleASM = new JToggleButton("Enable Speech");
        speechToggleASM.setFont(new Font("Arial", Font.BOLD, 12));
        speechToggleASM.setBackground(new Color(147, 112, 219));
        speechToggleASM.setForeground(Color.magenta);
        speechToggleASM.setToolTipText("Toggle text-to-speech");
        
        buttonPanelASM.add(sendButtonASM);
        buttonPanelASM.add(clearButtonASM);
        buttonPanelASM.add(speechToggleASM);
        
        inputPanelASM.add(messageFieldASM, BorderLayout.CENTER);
        inputPanelASM.add(buttonPanelASM, BorderLayout.EAST);
        
        mainPanelASM.add(scrollPaneASM, BorderLayout.CENTER);
        mainPanelASM.add(inputPanelASM, BorderLayout.SOUTH);
        
        add(mainPanelASM);
        
        sendButtonASM.addActionListener(e -> sendMessage());
        clearButtonASM.addActionListener(e -> messageFieldASM.setText(""));
        messageFieldASM.addActionListener(e -> sendMessage());
        
        speechToggleASM.addActionListener(e -> {
            if (speechToggleASM.isSelected()) {
                speechToggleASM.setText("Disable Speech");
            } else {
                speechToggleASM.setText("Enable Speech");
            }
        });
        
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                clientASM.disconnect();
            }
        });
        
        appendToPane(conversationPaneASM, "Fortune Teller: ", new Color(128, 0, 128), Font.BOLD);
        appendToPane(conversationPaneASM, "Hello, " + userASM.getUsernameASM() + "! Are you having a good day?\n", 
                new Color(128, 0, 128), Font.PLAIN);
    }
    
    private void sendMessage() {
        String messageASM = messageFieldASM.getText().trim();
        if (!messageASM.isEmpty()) {
            boolean sentASM = clientASM.sendMessage(messageASM);
            if (sentASM) {
                appendToPane(conversationPaneASM, userASM.getUsernameASM() + ": ", Color.BLUE, Font.BOLD);
                appendToPane(conversationPaneASM, messageASM + "\n", Color.BLUE, Font.PLAIN);
                
                if (speechToggleASM.isSelected()) {
                    speakText(userASM.getUsernameASM() + ": " + messageASM);
                }
                
                messageFieldASM.setText("");
            } else {
                JOptionPane.showMessageDialog(this, 
                    "Failed to send message. Please check your connection.",
                    "Communication Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
//    private void handleIncomingMessage(Message messageASM) {
//        SwingUtilities.invokeLater(() -> {
//            // Check message type
//            if (messageASM.getTypeASM() == Message.FORTUNE_RESPONSE) {
//                // Display the fortune response
//                appendToPane(conversationPaneASM, "Fortune Teller: ", new Color(128, 0, 128), Font.BOLD);
//                appendToPane(conversationPaneASM, messageASM.getContentASM() + "\n", new Color(128, 0, 128), Font.PLAIN);
//                
//                // Text-to-speech if enabled
//                if (speechToggleASM.isSelected()) {
//                    speakText("Fortune Teller: " + messageASM.getContentASM());
//                }
//            } else if (messageASM.getTypeASM() == Message.LOGIN_RESPONSE || 
//                       messageASM.getTypeASM() == Message.SIGNUP_RESPONSE) {
//                // Handle login/signup responses if needed
//                // These are typically handled in the LoginGUI, but might be relevant here
//                // for session validation
//                if (!messageASM.isSuccessASM()) {
//                    JOptionPane.showMessageDialog(this, 
//                        "Session error: " + messageASM.getContentASM(),
//                        "Session Error", JOptionPane.ERROR_MESSAGE);
//                    // Possibly close this window and go back to login
//                }
//            }
//        });
//    }
    
    private void handleIncomingMessage(Message messageASM) {
    SwingUtilities.invokeLater(() -> {
        if (messageASM.getTypeASM() == Message.FORTUNE_RESPONSE || 
            messageASM.getTypeASM() == Message.ERROR) {
            appendToPane(conversationPaneASM, "Fortune Teller: ", new Color(128, 0, 128), Font.BOLD);
            appendToPane(conversationPaneASM, messageASM.getContentASM() + "\n", new Color(128, 0, 128), Font.PLAIN);
            
            if (speechToggleASM.isSelected()) {
                speakText("Fortune Teller: " + messageASM.getContentASM());
            }
        } else if (messageASM.getTypeASM() == Message.LOGIN_RESPONSE) {
            if (!messageASM.isSuccessASM()) {
                appendToPane(conversationPaneASM, "System: ", Color.RED, Font.BOLD);
                appendToPane(conversationPaneASM, "Login failed: " + messageASM.getContentASM() + "\n", Color.RED, Font.PLAIN);
                
                JOptionPane.showMessageDialog(this, 
                    "Login error: " + messageASM.getContentASM(),
                    "Login Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            appendToPane(conversationPaneASM, "Fortune Teller: ", new Color(128, 0, 128), Font.BOLD);
            appendToPane(conversationPaneASM, messageASM.getContentASM() + "\n", new Color(128, 0, 128), Font.PLAIN);
            
            if (speechToggleASM.isSelected()) {
                speakText("Fortune Teller: " + messageASM.getContentASM());
            }
        }
    });
}
    
    public void displayMessage(Message messageASM) {
        handleIncomingMessage(messageASM);
    }
    
    private void appendToPane(JTextPane tpASM, String msgASM, Color cASM, int styleASM) {
        StyledDocument docASM = tpASM.getStyledDocument();
        StyleContext scASM = StyleContext.getDefaultStyleContext();
        AttributeSet asetASM = scASM.addAttribute(SimpleAttributeSet.EMPTY, StyleConstants.Foreground, cASM);
        asetASM = scASM.addAttribute(asetASM, StyleConstants.FontFamily, "Arial");
        asetASM = scASM.addAttribute(asetASM, StyleConstants.FontSize, 14);
        
        if (styleASM == Font.BOLD) {
            asetASM = scASM.addAttribute(asetASM, StyleConstants.Bold, true);
        }
        
        try {
            int lenASM = docASM.getLength();
            docASM.insertString(lenASM, msgASM, asetASM);
            tpASM.setCaretPosition(docASM.getLength());
        } catch (Exception e) {
            System.err.println("Error appending text: " + e.getMessage());
        }
    }
    
    private void speakText(String textASM) {
        System.out.println("Speaking: " + textASM);
        
        // To implement real text-to-speech, you need FreeTTS library
        // Add these JAR files to your project:
        // - freetts-1.2.2.jar
        // - jsapi-1.0-base.jar
        
        // Once you add the libraries, you can uncomment this code:
        /*
        try {
            com.sun.speech.freetts.Voice voice;
            com.sun.speech.freetts.VoiceManager vm = com.sun.speech.freetts.VoiceManager.getInstance();
            voice = vm.getVoice("kevin16");
            if (voice != null) {
                voice.allocate();
                voice.speak(textASM);
                voice.deallocate();
            }
        } catch (Exception e) {
            System.err.println("Error with text-to-speech: " + e.getMessage());
        }
        */
    }
}