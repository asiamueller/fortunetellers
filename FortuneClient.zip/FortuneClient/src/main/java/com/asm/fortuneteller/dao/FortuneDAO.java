package com.asm.fortuneteller.dao;

import com.asm.fortuneteller.model.Fortune;
import com.asm.fortuneteller.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class FortuneDAO {
    
    public List<Fortune> getAllFortunes() {
        Connection connASM = null;
        Statement stmtASM = null;
        ResultSet rsASM = null;
        List<Fortune> fortunesASM = new ArrayList<>();
        
        try {
            connASM = DatabaseUtil.getConnection();
            stmtASM = connASM.createStatement();
            String sqlASM = "SELECT id, content, type FROM fortunes";
            rsASM = stmtASM.executeQuery(sqlASM);
            
            while (rsASM.next()) {
                Fortune fortuneASM = new Fortune(
                    rsASM.getInt("id"),
                    rsASM.getString("content"),
                    rsASM.getString("type")
                );
                fortunesASM.add(fortuneASM);
            }
        } catch (SQLException e) {
            System.err.println("Error getting fortunes: " + e.getMessage());
        } finally {
            DatabaseUtil.closeResources(connASM, stmtASM, rsASM);
        }
        
        return fortunesASM;
    }
    
    public List<Fortune> getFortunesByType(String typeASM) {
        Connection connASM = null;
        PreparedStatement stmtASM = null;
        ResultSet rsASM = null;
        List<Fortune> fortunesASM = new ArrayList<>();
        
        try {
            connASM = DatabaseUtil.getConnection();
            String sqlASM = "SELECT id, content, type FROM fortunes WHERE type = ?";
            stmtASM = connASM.prepareStatement(sqlASM);
            stmtASM.setString(1, typeASM);
            rsASM = stmtASM.executeQuery();
            
            while (rsASM.next()) {
                Fortune fortuneASM = new Fortune(
                    rsASM.getInt("id"),
                    rsASM.getString("content"),
                    rsASM.getString("type")
                );
                fortunesASM.add(fortuneASM);
            }
        } catch (SQLException e) {
            System.err.println("Error getting fortunes by type: " + e.getMessage());
        } finally {
            DatabaseUtil.closeResources(connASM, stmtASM, rsASM);
        }
        
        return fortunesASM;
    }
    
    public Fortune getRandomFortune(String typeASM) {
        List<Fortune> fortunesASM = getFortunesByType(typeASM);
        if (fortunesASM.isEmpty()) {
            return null;
        }
        
        Random randomASM = new Random();
        int indexASM = randomASM.nextInt(fortunesASM.size());
        return fortunesASM.get(indexASM);
    }
    
    public Fortune getRandomFortune() {
        List<String> typesASM = new ArrayList<>();
        typesASM.add("positive");
        typesASM.add("negative");
        
        Random randomASM = new Random();
        String randomTypeASM = typesASM.get(randomASM.nextInt(typesASM.size()));
        
        return getRandomFortune(randomTypeASM);
    }
    
    // Initialize the fortunes table if it doesn't exist
    public void initializeTable() {
        Connection connASM = null;
        Statement stmtASM = null;
        
        try {
            connASM = DatabaseUtil.getConnection();
            stmtASM = connASM.createStatement();
            
            // Create fortunes table if it doesn't exist
            String createTableSqlASM = 
                "CREATE TABLE IF NOT EXISTS fortunes (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "content TEXT NOT NULL, " +
                "type TEXT NOT NULL)";
            
            stmtASM.executeUpdate(createTableSqlASM);
            
            // Check if we need to populate with sample data
            String countSqlASM = "SELECT COUNT(*) FROM fortunes";
            ResultSet rsASM = stmtASM.executeQuery(countSqlASM);
            
            if (rsASM.next() && rsASM.getInt(1) == 0) {
                // Sample positive fortunes
                String[] positiveFortunesASM = {
                    "great wealth and success",
                    "a happy journey with many new friends",
                    "an opportunity that will change your life",
                    "the love of your life very soon",
                    "professional success in your chosen field",
                    "a surprising gift from someone unexpected"
                };
                
                // Sample negative fortunes
                String[] negativeFortunesASM = {
                    "difficult challenges that will test your resilience",
                    "unexpected changes to your plans",
                    "a period of self-reflection and growth",
                    "hard work that will eventually pay off",
                    "a misunderstanding with a close friend",
                    "a lesson that might be hard to learn at first"
                };
                
                // Insert positive fortunes
                for (String fortuneASM : positiveFortunesASM) {
                    stmtASM.executeUpdate("INSERT INTO fortunes (content, type) VALUES ('" + fortuneASM + "', 'positive')");
                }
                
                // Insert negative fortunes
                for (String fortuneASM : negativeFortunesASM) {
                    stmtASM.executeUpdate("INSERT INTO fortunes (content, type) VALUES ('" + fortuneASM + "', 'negative')");
                }
            }
            
            if (rsASM != null) {
                rsASM.close();
            }
            
        } catch (SQLException e) {
            System.err.println("Error initializing fortunes table: " + e.getMessage());
        } finally {
            DatabaseUtil.closeResources(connASM, stmtASM, null);
        }
    }
}